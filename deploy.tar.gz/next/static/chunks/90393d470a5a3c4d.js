__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/168291d7a68f6c5f.js",
  "static/chunks/turbopack-2b3e07ecac72b382.js"
])
