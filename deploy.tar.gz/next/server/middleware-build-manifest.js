globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/168291d7a68f6c5f.js",
      "static/chunks/turbopack-2b3e07ecac72b382.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/168291d7a68f6c5f.js",
      "static/chunks/turbopack-fc9cfc1f5cf1fc3f.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2299ce4f05bad529.js",
    "static/chunks/3449ba750ff23d63.js",
    "static/chunks/75fa4d9e07841138.js",
    "static/chunks/turbopack-c0d7b248e4985e1a.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];