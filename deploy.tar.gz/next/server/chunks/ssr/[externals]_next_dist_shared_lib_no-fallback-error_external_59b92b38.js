module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))}];

//# sourceMappingURL=%5Bexternals%5D_next_dist_shared_lib_no-fallback-error_external_59b92b38.js.map