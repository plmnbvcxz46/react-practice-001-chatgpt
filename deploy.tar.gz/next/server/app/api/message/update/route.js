var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/message/update/route.js")
R.c("server/chunks/[root-of-the-server]__9d4623fc._.js")
R.c("server/chunks/node_modules_next_dist_4ac85b6e._.js")
R.c("server/chunks/[root-of-the-server]__a3cd3f76._.js")
R.m(93243)
R.m(22067)
module.exports=R.m(22067).exports
