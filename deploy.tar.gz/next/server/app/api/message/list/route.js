var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/message/list/route.js")
R.c("server/chunks/[root-of-the-server]__e2aee1e5._.js")
R.c("server/chunks/node_modules_next_dist_4ac85b6e._.js")
R.c("server/chunks/[root-of-the-server]__a3cd3f76._.js")
R.m(38286)
R.m(9267)
module.exports=R.m(9267).exports
