var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/route.js")
R.c("server/chunks/[root-of-the-server]__0711dc22._.js")
R.c("server/chunks/[root-of-the-server]__a333e2fa._.js")
R.c("server/chunks/node_modules_next_dist_4ac85b6e._.js")
R.m(43561)
R.m(61378)
module.exports=R.m(61378).exports
