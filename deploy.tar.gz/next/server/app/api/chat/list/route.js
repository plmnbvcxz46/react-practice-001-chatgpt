var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/chat/list/route.js")
R.c("server/chunks/[root-of-the-server]__9a47e910._.js")
R.c("server/chunks/node_modules_next_dist_4ac85b6e._.js")
R.c("server/chunks/[root-of-the-server]__a3cd3f76._.js")
R.m(77655)
R.m(17730)
module.exports=R.m(17730).exports
